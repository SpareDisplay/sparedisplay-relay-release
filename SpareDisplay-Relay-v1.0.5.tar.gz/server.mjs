import { createHash, createHmac, randomBytes, timingSafeEqual } from "node:crypto";
import { createServer } from "node:http";

const PORT = Number(process.env.PORT ?? 8787);
const SIGNALING_SECRET = process.env.REMOTE_SIGNALING_SECRET ?? "";
const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL ?? "";
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY ?? "";
const TURN_SHARED_SECRET = process.env.TURN_SHARED_SECRET ?? "";

if (!SIGNALING_SECRET || !SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
  throw new Error("REMOTE_SIGNALING_SECRET, NEXT_PUBLIC_SUPABASE_URL, and SUPABASE_SERVICE_ROLE_KEY are required");
}

const MAX_PAYLOAD_BYTES = 1024 * 1024; // 1 MB max message size
const RATE_LIMIT_MAX = 100; // messages per second
const HEARTBEAT_INTERVAL_MS = 30_000;
const HEARTBEAT_TIMEOUT_MS = 10_000;
const SESSION_ID_PATTERN = /^[a-zA-Z0-9_-]{1,128}$/;
const MAX_ANONYMOUS_CONNECTIONS = 1000; // global limit on unauthenticated connections
const RELAY_DATA_RATE_LIMIT_BYTES = 5 * 1024 * 1024; // 5 MB/s per session
const PENDING_SESSION_TIMEOUT_MS = 30_000; // 30s timeout for device to accept

const deviceSockets = new Map();
const sessionRoutes = new Map();

// --- Session codes: code-based remote access ---
const sessionCodes = new Map();     // code -> { deviceClient, deviceId, deviceName, userId, createdAt, expiresAt }
const codeByDeviceId = new Map();   // deviceId -> code (reverse lookup for cleanup)
const SESSION_CODE_TTL_MS = 4 * 60 * 60 * 1000; // 4 hours
const CODE_ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"; // 30 chars, no ambiguous 0/O/1/I/L
const CODE_JOIN_RATE_LIMIT = 5; // max attempts per IP per minute
const codeJoinAttempts = new Map(); // ip -> { count, resetAt }

// Sanitize device name to prevent log injection and limit length
function sanitizeDeviceName(name) {
  if (typeof name !== "string") return "Remote Device";
  return name.replace(/[\x00-\x1f\x7f]/g, "").slice(0, 120) || "Remote Device";
}

function generateSessionCode() {
  const bytes = randomBytes(12);
  let code = "";
  for (let i = 0; i < 12; i++) code += CODE_ALPHABET[bytes[i] % CODE_ALPHABET.length];
  return `${code.slice(0, 4)}-${code.slice(4, 8)}-${code.slice(8, 12)}`;
}

// HORIZON-16: Usage metering — track bytes relayed per session
const sessionMetrics = new Map();
const METRICS_FLUSH_INTERVAL_MS = 60_000; // flush every 60s

setInterval(() => {
  void flushMetrics();
}, METRICS_FLUSH_INTERVAL_MS);

// Periodic sweep to remove expired session codes and notify active sessions
setInterval(() => {
  const now = Date.now();
  for (const [code, entry] of sessionCodes.entries()) {
    if (now >= entry.expiresAt) {
      sessionCodes.delete(code);
      if (codeByDeviceId.get(entry.deviceId) === code) {
        codeByDeviceId.delete(entry.deviceId);
      }
      // Notify the device that its code expired
      if (entry.deviceClient && !entry.deviceClient.socket.destroyed) {
        try {
          sendJson(entry.deviceClient, { type: "session_code_invalidated", code, reason: "expired" });
        } catch {
          // socket may already be dead
        }
      }
    }
  }
  // Clean up stale rate limit entries
  for (const [ip, bucket] of codeJoinAttempts.entries()) {
    if (now > bucket.resetAt) codeJoinAttempts.delete(ip);
  }
}, 60_000);

const server = createServer((request, response) => {
  if (request.url === "/healthz") {
    response.writeHead(200, { "content-type": "application/json" });
    response.end(JSON.stringify({ ok: true }));
    return;
  }

  response.writeHead(404, { "content-type": "application/json" });
  response.end(JSON.stringify({ error: "Not found" }));
});

// --- Heartbeat / ping-pong ---
const heartbeatInterval = setInterval(() => {
  const now = Date.now();
  for (const client of allClients) {
    if (client.isAlive === false) {
      // Did not respond to previous ping — notify active sessions before destroying
      for (const [sessionId, route] of sessionRoutes.entries()) {
        if (route.client === client || route.device === client) {
          const peer = route.client === client ? route.device : route.client;
          try {
            sendJson(peer, { type: "session_ended", sessionId, reason: "peer_timeout" });
          } catch {
            // peer socket may already be dead
          }
        }
      }
      client.socket.destroy();
      void cleanupClient(client);
      continue;
    }
    client.isAlive = false;
    // Send WebSocket ping frame (opcode 0x09)
    try {
      client.socket.write(encodeFrame(Buffer.alloc(0), 0x09));
    } catch {
      // socket already dead
    }
  }
}, HEARTBEAT_INTERVAL_MS);

// Timeout pending session routes that the device never acknowledged
setInterval(() => {
  const now = Date.now();
  for (const [sessionId, route] of sessionRoutes.entries()) {
    if (route.pending && now - route.pendingSince >= PENDING_SESSION_TIMEOUT_MS) {
      sessionRoutes.delete(sessionId);
      try {
        sendJson(route.client, { type: "session_ended", sessionId, reason: "connection_timeout" });
      } catch {
        // client socket may already be dead
      }
      try {
        sendJson(route.device, { type: "session_ended", sessionId, reason: "connection_timeout" });
      } catch {
        // device socket may already be dead
      }
      sessionMetrics.delete(sessionId);
    }
  }
}, HEARTBEAT_INTERVAL_MS);

// Track all connected clients for heartbeat iteration
const allClients = new Set();

server.on("upgrade", (request, socket) => {
  const upgrade = String(request.headers.upgrade ?? "").toLowerCase();
  const key = String(request.headers["sec-websocket-key"] ?? "");

  if (upgrade !== "websocket" || !key) {
    socket.destroy();
    return;
  }

  // --- Authentication: allow anonymous connections for session code joins ---
  const url = new URL(request.url ?? "/", `http://${request.headers.host ?? "localhost"}`);
  const authToken = url.searchParams.get("token") ?? request.headers["x-auth-token"] ?? "";
  const authPayload = authToken
    ? (verifyToken(String(authToken), "client_access") ?? verifyToken(String(authToken), "device_registration"))
    : null;

  // Anonymous connections are allowed — they can only use join_session_code
  // Enforce global limit on anonymous connections to prevent DoS
  if (!authPayload) {
    let anonCount = 0;
    for (const c of allClients) {
      if (c.role === "anonymous_unauthed") anonCount++;
    }
    if (anonCount >= MAX_ANONYMOUS_CONNECTIONS) {
      socket.destroy();
      return;
    }
  }

  const accept = createHash("sha1")
    .update(`${key}258EAFA5-E914-47DA-95CA-C5AB0DC85B11`)
    .digest("base64");

  socket.write(
    [
      "HTTP/1.1 101 Switching Protocols",
      "Upgrade: websocket",
      "Connection: Upgrade",
      `Sec-WebSocket-Accept: ${accept}`,
      "\r\n"
    ].join("\r\n")
  );

  const client = {
    socket,
    buffer: Buffer.alloc(0),
    role: authPayload ? "anonymous" : "anonymous_unauthed",
    userId: authPayload?.userId ?? null,
    deviceId: null,
    // Device ownership tracking
    ownedDeviceIds: new Set(),
    // Rate limiting
    messageCount: 0,
    rateLimitReset: Date.now() + 1000,
    // Heartbeat
    isAlive: true
  };

  allClients.add(client);
  console.log(`[relay] new connection (role=${client.role}, userId=${client.userId})`);

  socket.on("data", (chunk) => {
    client.buffer = Buffer.concat([client.buffer, chunk]);

    // Limit buffer size to prevent memory abuse
    if (client.buffer.length > MAX_PAYLOAD_BYTES * 2) {
      closeWithCode(client, 4008, "Message too large");
      return;
    }

    for (const frame of decodeFrames(client)) {
      handleFrame(client, frame).catch((error) => {
        sendJson(client, { type: "error", error: error.message });
      });
    }
  });

  socket.on("close", () => {
    allClients.delete(client);
    void cleanupClient(client);
  });

  socket.on("end", () => {
    allClients.delete(client);
    void cleanupClient(client);
  });

  socket.on("error", () => {
    allClients.delete(client);
    void cleanupClient(client);
  });
});

server.listen(PORT, () => {
  console.log(`[relay-server] listening on :${PORT}`);
});

// --- Session ID validation ---
function isValidSessionId(sessionId) {
  return typeof sessionId === "string" && SESSION_ID_PATTERN.test(sessionId);
}

async function handleFrame(client, frame) {
  if (frame.opcode === 0x08) {
    client.socket.end();
    return;
  }

  // Handle pong frames — mark client as alive
  if (frame.opcode === 0x0a) {
    client.isAlive = true;
    return;
  }

  if (frame.opcode === 0x09) {
    client.socket.write(encodeFrame(frame.payload, 0x0a));
    return;
  }

  if (frame.opcode !== 0x01) {
    return;
  }

  // --- Rate limiting ---
  const now = Date.now();
  if (now > client.rateLimitReset) {
    client.messageCount = 0;
    client.rateLimitReset = now + 1000;
  }
  client.messageCount++;
  if (client.messageCount > RATE_LIMIT_MAX) {
    closeWithCode(client, 4029, "Rate limited");
    return;
  }

  // --- Max payload size check ---
  if (frame.payload.length > MAX_PAYLOAD_BYTES) {
    closeWithCode(client, 4008, "Message too large");
    return;
  }

  const message = JSON.parse(frame.payload.toString("utf8"));
  console.log(`[relay] msg: type=${message.type} role=${client.role}`);

  // Anonymous unauthed clients can only join via session code or register a device
  if (client.role === "anonymous_unauthed" && message.type !== "join_session_code" && message.type !== "register_device") {
    sendJson(client, { type: "error", error: "Authentication required. Only join_session_code and register_device are allowed." });
    return;
  }

  switch (message.type) {
    case "register_device":
      await handleRegisterDevice(client, message);
      return;
    case "heartbeat":
      await handleHeartbeat(client, message);
      return;
    case "list_devices":
      await handleListDevices(client, message);
      return;
    case "request_connection":
      await handleRequestConnection(client, message);
      return;
    case "signal":
      await handleSignal(client, message);
      return;
    case "relay_data":
      await handleRelayData(client, message);
      return;
    case "key_exchange":
      await handleKeyExchange(client, message);
      return;
    case "get_turn_credentials":
      await handleGetTurnCredentials(client, message);
      return;
    case "create_session_code":
      await handleCreateSessionCode(client, message);
      return;
    case "join_session_code":
      await handleJoinSessionCode(client, message);
      return;
    case "invalidate_session_code":
      await handleInvalidateSessionCode(client, message);
      return;
    case "connection_accepted":
      await handleConnectionAccepted(client, message);
      return;
    default:
      sendJson(client, { type: "error", error: "Unsupported message type" });
  }
}

async function handleRegisterDevice(client, message) {
  console.log(`[relay] register_device deviceId=${message.deviceId}`);
  const payload = verifyToken(message.token, "device_registration");
  if (!payload || payload.deviceId !== message.deviceId) {
    console.log(`[relay] register_device REJECTED (token invalid or deviceId mismatch)`);
    sendJson(client, { type: "error", error: "Invalid device registration token" });
    return;
  }

  // If this device was previously registered (reconnect), clean up old session code
  const oldCode = codeByDeviceId.get(payload.deviceId);
  if (oldCode) {
    sessionCodes.delete(oldCode);
    codeByDeviceId.delete(payload.deviceId);
  }

  // If another client object held this deviceId, clean up its stale routes
  const oldClient = deviceSockets.get(payload.deviceId);
  if (oldClient && oldClient !== client) {
    for (const [sessionId, route] of sessionRoutes.entries()) {
      if (route.device === oldClient) {
        sessionRoutes.delete(sessionId);
        try {
          sendJson(route.client, { type: "session_ended", sessionId, reason: "host_reconnected" });
        } catch {
          // client socket may already be dead
        }
        sessionMetrics.delete(sessionId);
      }
    }
  }

  client.role = "device";
  client.userId = payload.userId;
  client.deviceId = payload.deviceId;
  client.features = payload.features ?? [];
  client.ownedDeviceIds.add(payload.deviceId);
  deviceSockets.set(payload.deviceId, client);

  await upsertRemoteDevice({
    user_id: payload.userId,
    device_id: payload.deviceId,
    device_name: sanitizeDeviceName(message.deviceName ?? payload.deviceName),
    platform: message.platform ?? payload.platform ?? "unknown",
    status: "online",
    last_seen_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    metadata: {
      ip: client.socket.remoteAddress ?? null
    }
  });

  console.log(`[relay] device registered: ${payload.deviceId} (userId=${payload.userId})`);
  sendJson(client, { type: "registered", deviceId: payload.deviceId });
}

async function handleHeartbeat(client, message) {
  const payload = verifyToken(message.token, "device_registration");
  if (!payload || payload.deviceId !== client.deviceId) {
    sendJson(client, { type: "error", error: "Invalid heartbeat token" });
    return;
  }

  await upsertRemoteDevice({
    user_id: payload.userId,
    device_id: payload.deviceId,
    device_name: sanitizeDeviceName(message.deviceName ?? payload.deviceName),
    platform: message.platform ?? payload.platform ?? "unknown",
    status: "online",
    last_seen_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    metadata: {
      ip: client.socket.remoteAddress ?? null
    }
  });

  sendJson(client, { type: "heartbeat_ack", deviceId: payload.deviceId });
}

async function handleListDevices(client, message) {
  const payload = verifyToken(message.token, "client_access");
  if (!payload) {
    sendJson(client, { type: "error", error: "Invalid client access token" });
    return;
  }

  client.role = "client";
  client.userId = payload.userId;

  const devices = await queryRemoteDevices(payload.userId);
  sendJson(client, { type: "device_list", devices });
}

async function handleRequestConnection(client, message) {
  const payload = verifyToken(message.token, "client_access");
  if (!payload) {
    sendJson(client, { type: "error", error: "Invalid client access token" });
    return;
  }

  const targetDeviceId = String(message.targetDeviceId ?? "");
  const target = deviceSockets.get(targetDeviceId);
  if (!target) {
    sendJson(client, { type: "error", error: "Target device is offline" });
    return;
  }

  // --- Device ownership check: target device must belong to the same user ---
  if (target.userId !== payload.userId) {
    sendJson(client, { type: "error", error: "Access denied: device does not belong to this user" });
    return;
  }

  const sessionId = String(message.sessionId ?? "").trim();
  if (!isValidSessionId(sessionId)) {
    sendJson(client, { type: "error", error: "Invalid sessionId format" });
    return;
  }

  sessionRoutes.set(sessionId, { client, device: target });
  sendJson(target, {
    type: "connection_request",
    sessionId,
    userId: payload.userId,
    deviceId: message.targetDeviceId
  });
  sendJson(client, { type: "connection_pending", sessionId, deviceId: message.targetDeviceId });
}

async function handleSignal(client, message) {
  const sessionId = String(message.sessionId ?? "").trim();
  if (!isValidSessionId(sessionId)) {
    sendJson(client, { type: "error", error: "Invalid sessionId format" });
    return;
  }

  const route = sessionRoutes.get(sessionId);
  if (!route) {
    sendJson(client, { type: "error", error: "Unknown signaling session" });
    return;
  }

  if (client === route.client) {
    sendJson(route.device, {
      type: "signal",
      sessionId,
      payload: message.payload ?? null
    });
    return;
  }

  if (client === route.device) {
    // Implicit acceptance: device sending a signal promotes a pending session
    if (route.pending) {
      promotePendingRoute(sessionId, route, client);
    }
    sendJson(route.client, {
      type: "signal",
      sessionId,
      payload: message.payload ?? null
    });
    return;
  }

  sendJson(client, { type: "error", error: "Socket is not part of this session" });
}

// --- Key exchange message forwarding for E2E encryption setup ---
async function handleKeyExchange(client, message) {
  const sessionId = String(message.sessionId ?? "").trim();
  if (!isValidSessionId(sessionId)) {
    sendJson(client, { type: "error", error: "Invalid sessionId format" });
    return;
  }

  const route = sessionRoutes.get(sessionId);
  if (!route) {
    sendJson(client, { type: "error", error: "Unknown session for key exchange" });
    return;
  }

  const keyPayload = message.payload ?? null;
  if (!keyPayload) {
    sendJson(client, { type: "error", error: "Key exchange payload is required" });
    return;
  }

  if (client === route.client) {
    sendJson(route.device, {
      type: "key_exchange",
      sessionId,
      payload: keyPayload
    });
    return;
  }

  if (client === route.device) {
    // Implicit acceptance: device sending key_exchange promotes a pending session
    if (route.pending) {
      promotePendingRoute(sessionId, route, client);
    }
    sendJson(route.client, {
      type: "key_exchange",
      sessionId,
      payload: keyPayload
    });
    return;
  }

  sendJson(client, { type: "error", error: "Socket is not part of this session" });
}

async function cleanupClient(client) {
  if (client.deviceId && deviceSockets.get(client.deviceId) === client) {
    deviceSockets.delete(client.deviceId);
    await updateRemoteDeviceStatus(client.deviceId, "offline");
  }

  // Clean up all owned device registrations and their session codes
  for (const deviceId of client.ownedDeviceIds) {
    if (deviceSockets.get(deviceId) === client) {
      deviceSockets.delete(deviceId);
      await updateRemoteDeviceStatus(deviceId, "offline");
    }
    // Remove session code for this device
    const code = codeByDeviceId.get(deviceId);
    if (code) {
      sessionCodes.delete(code);
      codeByDeviceId.delete(deviceId);
    }
  }
  client.ownedDeviceIds.clear();

  // --- Session cleanup: notify peer and remove sessions ---
  for (const [sessionId, route] of sessionRoutes.entries()) {
    if (route.client === client || route.device === client) {
      sessionRoutes.delete(sessionId);

      // Notify the other participant that the session ended
      const peer = route.client === client ? route.device : route.client;
      try {
        sendJson(peer, { type: "session_ended", sessionId, reason: "peer_disconnected" });
      } catch {
        // peer socket may already be dead
      }

      // Flush final metrics for the ended session
      const metrics = sessionMetrics.get(sessionId);
      if (metrics && (metrics.bytesIn > 0 || metrics.bytesOut > 0)) {
        const durationSeconds = Math.floor((Date.now() - metrics.startedAt) / 1000);
        const url = new URL("/rest/v1/relay_usage", SUPABASE_URL);
        fetch(url, {
          method: "POST",
          headers: {
            ...supabaseHeaders(),
            "content-type": "application/json",
            prefer: "return=minimal"
          },
          body: JSON.stringify({
            user_id: metrics.userId,
            session_id: sessionId,
            bytes_in: metrics.bytesIn,
            bytes_out: metrics.bytesOut,
            duration_seconds: durationSeconds,
            created_at: new Date().toISOString()
          })
        }).catch(() => {});
      }
      sessionMetrics.delete(sessionId);
    }
  }
}

function verifyToken(token, expectedKind) {
  const [encodedPayload, signature] = String(token ?? "").split(".");
  if (!encodedPayload || !signature) {
    return null;
  }

  const expectedSignature = createHmac("sha256", SIGNALING_SECRET)
    .update(encodedPayload)
    .digest("base64url");

  const left = Buffer.from(signature);
  const right = Buffer.from(expectedSignature);
  if (left.length !== right.length || !timingSafeEqual(left, right)) {
    return null;
  }

  try {
    const payload = JSON.parse(Buffer.from(encodedPayload, "base64url").toString("utf8"));
    if (payload.kind !== expectedKind || payload.exp * 1000 < Date.now()) {
      return null;
    }
    return payload;
  } catch {
    return null;
  }
}

async function queryRemoteDevices(userId) {
  const url = new URL("/rest/v1/remote_devices", SUPABASE_URL);
  url.searchParams.set("select", "device_id,device_name,platform,status,last_seen_at,updated_at");
  url.searchParams.set("user_id", `eq.${userId}`);
  url.searchParams.set("order", "last_seen_at.desc");

  const response = await fetch(url, {
    headers: supabaseHeaders()
  });

  if (!response.ok) {
    throw new Error(`Failed to query remote devices: ${response.status}`);
  }

  const devices = await response.json();
  return devices.map((device) => ({
    deviceId: device.device_id,
    deviceName: device.device_name,
    platform: device.platform,
    status: device.status,
    lastSeenAt: device.last_seen_at,
    updatedAt: device.updated_at
  }));
}

async function upsertRemoteDevice(device) {
  const url = new URL("/rest/v1/remote_devices", SUPABASE_URL);
  url.searchParams.set("on_conflict", "device_id");

  const response = await fetch(url, {
    method: "POST",
    headers: {
      ...supabaseHeaders(),
      "content-type": "application/json",
      prefer: "resolution=merge-duplicates"
    },
    body: JSON.stringify(device)
  });

  if (!response.ok) {
    throw new Error(`Failed to upsert remote device: ${response.status}`);
  }
}

async function updateRemoteDeviceStatus(deviceId, status) {
  const url = new URL("/rest/v1/remote_devices", SUPABASE_URL);
  url.searchParams.set("device_id", `eq.${deviceId}`);

  const response = await fetch(url, {
    method: "PATCH",
    headers: {
      ...supabaseHeaders(),
      "content-type": "application/json"
    },
    body: JSON.stringify({
      status,
      updated_at: new Date().toISOString()
    })
  });

  if (!response.ok) {
    throw new Error(`Failed to update device status: ${response.status}`);
  }
}

function supabaseHeaders() {
  return {
    apikey: SUPABASE_SERVICE_ROLE_KEY,
    authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`
  };
}

// --- Session code handlers ---

async function handleCreateSessionCode(client, _message) {
  if (client.role !== "device") {
    sendJson(client, { type: "error", error: "Only registered devices can create session codes" });
    return;
  }

  // Defense in depth: verify the device has the remote_access feature
  if (!Array.isArray(client.features) || !client.features.includes("remote_access")) {
    sendJson(client, { type: "error", error: "Remote access requires a Pro license" });
    return;
  }

  // If device already has a code, return it
  const existingCode = codeByDeviceId.get(client.deviceId);
  if (existingCode && sessionCodes.has(existingCode)) {
    const entry = sessionCodes.get(existingCode);
    sendJson(client, {
      type: "session_code_created",
      code: existingCode,
      expiresAt: new Date(entry.expiresAt).toISOString()
    });
    return;
  }

  // Generate a unique code
  let code;
  let attempts = 0;
  do {
    code = generateSessionCode();
    attempts++;
  } while (sessionCodes.has(code) && attempts < 10);

  if (sessionCodes.has(code)) {
    sendJson(client, { type: "error", error: "Failed to generate unique session code" });
    return;
  }

  const now = Date.now();
  const expiresAt = now + SESSION_CODE_TTL_MS;

  sessionCodes.set(code, {
    deviceClient: client,
    deviceId: client.deviceId,
    deviceName: sanitizeDeviceName(_message.deviceName),
    userId: client.userId,
    createdAt: now,
    expiresAt
  });
  codeByDeviceId.set(client.deviceId, code);

  sendJson(client, {
    type: "session_code_created",
    code,
    expiresAt: new Date(expiresAt).toISOString()
  });
}

async function handleJoinSessionCode(client, message) {
  // Rate limit per IP
  const ip = client.socket.remoteAddress ?? "unknown";
  const now = Date.now();
  let bucket = codeJoinAttempts.get(ip);
  if (!bucket || now > bucket.resetAt) {
    bucket = { count: 0, resetAt: now + 60_000 };
    codeJoinAttempts.set(ip, bucket);
  }
  bucket.count++;
  if (bucket.count > CODE_JOIN_RATE_LIMIT) {
    sendJson(client, { type: "error", error: "Invalid or expired session code" });
    return;
  }

  const rawCode = String(message.code ?? "").toUpperCase().replace(/[^A-Z0-9]/g, "");
  // Re-format to match stored format XXXX-XXXX-XXXX
  const normalizedCode = rawCode.length === 12
    ? `${rawCode.slice(0, 4)}-${rawCode.slice(4, 8)}-${rawCode.slice(8, 12)}`
    : String(message.code ?? "").toUpperCase().trim();

  const entry = sessionCodes.get(normalizedCode);
  if (!entry || now >= entry.expiresAt) {
    sendJson(client, { type: "error", error: "Invalid or expired session code" });
    return;
  }

  // Verify the device is still connected
  if (!entry.deviceClient || !entry.deviceClient.socket || entry.deviceClient.socket.destroyed) {
    sendJson(client, { type: "error", error: "Host device is no longer available" });
    sessionCodes.delete(normalizedCode);
    codeByDeviceId.delete(entry.deviceId);
    return;
  }

  // Create a session route (pending until device acknowledges by sending data)
  const sessionId = `sc-${randomBytes(16).toString("hex")}`;
  client.role = "client";
  sessionRoutes.set(sessionId, { client, device: entry.deviceClient, pending: true, pendingSince: Date.now() });

  // Notify the device of the incoming connection
  sendJson(entry.deviceClient, {
    type: "connection_request",
    sessionId,
    userId: client.userId ?? "anonymous",
    deviceId: entry.deviceId
  });

  // Tell the client to wait — session_code_joined is sent once the device responds
  sendJson(client, {
    type: "connection_pending",
    sessionId,
    deviceName: entry.deviceName
  });
}

async function handleInvalidateSessionCode(client, _message) {
  if (client.role !== "device") {
    sendJson(client, { type: "error", error: "Only registered devices can invalidate session codes" });
    return;
  }

  const code = codeByDeviceId.get(client.deviceId);
  if (!code) {
    sendJson(client, { type: "session_code_invalidated", code: null });
    return;
  }

  sessionCodes.delete(code);
  codeByDeviceId.delete(client.deviceId);

  // Kick all connected clients that were routed through this device
  for (const [sessionId, route] of sessionRoutes.entries()) {
    if (route.device === client) {
      sessionRoutes.delete(sessionId);
      try {
        sendJson(route.client, { type: "session_ended", sessionId, reason: "host_ended_session" });
      } catch {
        // client socket may already be dead
      }
      // Flush final metrics
      const metrics = sessionMetrics.get(sessionId);
      if (metrics && (metrics.bytesIn > 0 || metrics.bytesOut > 0)) {
        const durationSeconds = Math.floor((Date.now() - metrics.startedAt) / 1000);
        const url = new URL("/rest/v1/relay_usage", SUPABASE_URL);
        fetch(url, {
          method: "POST",
          headers: {
            ...supabaseHeaders(),
            "content-type": "application/json",
            prefer: "return=minimal"
          },
          body: JSON.stringify({
            user_id: metrics.userId,
            session_id: sessionId,
            bytes_in: metrics.bytesIn,
            bytes_out: metrics.bytesOut,
            duration_seconds: durationSeconds,
            created_at: new Date().toISOString()
          })
        }).catch(() => {});
      }
      sessionMetrics.delete(sessionId);
    }
  }

  sendJson(client, { type: "session_code_invalidated", code });
}

// --- Explicit connection acceptance by device ---
async function handleConnectionAccepted(client, message) {
  const sessionId = String(message.sessionId ?? "").trim();
  if (!isValidSessionId(sessionId)) {
    sendJson(client, { type: "error", error: "Invalid sessionId format" });
    return;
  }

  const route = sessionRoutes.get(sessionId);
  if (!route || route.device !== client) {
    sendJson(client, { type: "error", error: "Unknown session" });
    return;
  }

  if (route.pending) {
    promotePendingRoute(sessionId, route, client);
  }
}

// Promote a pending session route to active and notify the client
function promotePendingRoute(sessionId, route, deviceClient) {
  route.pending = false;
  delete route.pendingSince;

  const code = codeByDeviceId.get(deviceClient.deviceId);
  const entry = code ? sessionCodes.get(code) : null;
  sendJson(route.client, {
    type: "session_code_joined",
    sessionId,
    deviceName: entry?.deviceName ?? "Remote Device"
  });
}

// HORIZON-7: Relay raw protocol data between client and device WebSockets
// when WebRTC P2P is not possible (e.g., Mac server without native WebRTC).
async function handleRelayData(client, message) {
  const sessionId = String(message.sessionId ?? "").trim();
  if (!isValidSessionId(sessionId)) {
    sendJson(client, { type: "error", error: "Invalid sessionId format" });
    return;
  }

  const route = sessionRoutes.get(sessionId);
  if (!route) {
    sendJson(client, { type: "error", error: "Unknown relay session" });
    return;
  }

  const dataPayload = message.data ?? null;
  if (!dataPayload) return;

  const dataBytes = Buffer.byteLength(dataPayload, "utf8");

  // Track metrics for this session
  let metrics = sessionMetrics.get(sessionId);
  if (!metrics) {
    metrics = {
      userId: client.userId,
      sessionId,
      bytesIn: 0,
      bytesOut: 0,
      startedAt: Date.now(),
      rateLimitBytes: 0,
      rateLimitReset: Date.now() + 1000
    };
    sessionMetrics.set(sessionId, metrics);
  }

  // Per-session bandwidth rate limiting (reset every second)
  const now = Date.now();
  if (now > metrics.rateLimitReset) {
    metrics.rateLimitBytes = 0;
    metrics.rateLimitReset = now + 1000;
  }
  metrics.rateLimitBytes += dataBytes;
  if (metrics.rateLimitBytes > RELAY_DATA_RATE_LIMIT_BYTES) {
    return; // silently drop — client is sending too fast
  }

  if (client === route.client) {
    metrics.bytesIn += dataBytes;
    sendJson(route.device, {
      type: "signal",
      sessionId,
      payload: { type: "relay_data", data: dataPayload }
    });
    return;
  }

  if (client === route.device) {
    // Implicit acceptance: device sending relay data promotes a pending session
    if (route.pending) {
      promotePendingRoute(sessionId, route, client);
    }
    metrics.bytesOut += dataBytes;
    sendJson(route.client, {
      type: "signal",
      sessionId,
      payload: { type: "relay_data", data: dataPayload }
    });
    return;
  }

  sendJson(client, { type: "error", error: "Socket is not part of this relay session" });
}

// HORIZON-6: Provide TURN server credentials to clients
// Uses ephemeral HMAC-based credentials when TURN_SHARED_SECRET is set,
// falling back to static credentials from env vars.
async function handleGetTurnCredentials(client, message) {
  const payload = verifyToken(message.token, "client_access");
  if (!payload) {
    sendJson(client, { type: "error", error: "Invalid client access token" });
    return;
  }

  const turnUrl = process.env.TURN_SERVER_URL ?? "";

  if (!turnUrl) {
    sendJson(client, { type: "turn_credentials", credentials: null });
    return;
  }

  // Prefer ephemeral TURN credentials using shared secret (coturn REST API style)
  if (TURN_SHARED_SECRET) {
    const { username, credential, ttl } = generateTurnCredentials(
      payload.userId ?? "anonymous",
      TURN_SHARED_SECRET
    );

    sendJson(client, {
      type: "turn_credentials",
      credentials: {
        urls: [turnUrl],
        username,
        credential,
        ttl
      }
    });
    return;
  }

  // Fallback: static credentials from environment
  const turnUsername = process.env.TURN_USERNAME ?? "";
  const turnCredential = process.env.TURN_CREDENTIAL ?? "";

  sendJson(client, {
    type: "turn_credentials",
    credentials: {
      urls: [turnUrl],
      username: turnUsername,
      credential: turnCredential
    }
  });
}

// Generate time-limited TURN credentials using HMAC (coturn REST API / RFC 7635)
function generateTurnCredentials(username, secret, ttl = 86400) {
  const timestamp = Math.floor(Date.now() / 1000) + ttl;
  const turnUsername = `${timestamp}:${username}`;
  const hmac = createHmac("sha1", secret);
  hmac.update(turnUsername);
  const credential = hmac.digest("base64");
  return { username: turnUsername, credential, ttl };
}

// HORIZON-16: Flush accumulated relay usage metrics to Supabase
async function flushMetrics() {
  const entries = [...sessionMetrics.entries()];
  if (entries.length === 0) return;

  for (const [sessionId, metrics] of entries) {
    if (metrics.bytesIn === 0 && metrics.bytesOut === 0) continue;

    const durationSeconds = Math.floor((Date.now() - metrics.startedAt) / 1000);

    try {
      const url = new URL("/rest/v1/relay_usage", SUPABASE_URL);
      await fetch(url, {
        method: "POST",
        headers: {
          ...supabaseHeaders(),
          "content-type": "application/json",
          prefer: "return=minimal"
        },
        body: JSON.stringify({
          user_id: metrics.userId,
          session_id: sessionId,
          bytes_in: metrics.bytesIn,
          bytes_out: metrics.bytesOut,
          duration_seconds: durationSeconds,
          created_at: new Date().toISOString()
        })
      });
    } catch (error) {
      console.error(`[relay-server] Failed to flush metrics for session ${sessionId}:`, error.message);
    }

    // Reset counters after flush (keep session alive)
    metrics.bytesIn = 0;
    metrics.bytesOut = 0;
  }
}

// --- WebSocket close with application-level close code ---
function closeWithCode(client, code, reason) {
  const reasonBuf = Buffer.from(reason, "utf8");
  const payload = Buffer.alloc(2 + reasonBuf.length);
  payload.writeUInt16BE(code, 0);
  reasonBuf.copy(payload, 2);
  try {
    client.socket.write(encodeFrame(payload, 0x08));
  } catch {
    // socket may already be dead
  }
  client.socket.destroy();
  allClients.delete(client);
  void cleanupClient(client);
}

function sendJson(client, payload) {
  client.socket.write(encodeFrame(Buffer.from(JSON.stringify(payload), "utf8")));
}

function decodeFrames(client) {
  const frames = [];
  let offset = 0;

  while (offset + 2 <= client.buffer.length) {
    const first = client.buffer[offset];
    const second = client.buffer[offset + 1];
    const masked = (second & 0x80) !== 0;
    let payloadLength = second & 0x7f;
    let headerLength = 2;

    if (payloadLength === 126) {
      if (offset + 4 > client.buffer.length) break;
      payloadLength = client.buffer.readUInt16BE(offset + 2);
      headerLength = 4;
    } else if (payloadLength === 127) {
      if (offset + 10 > client.buffer.length) break;
      payloadLength = Number(client.buffer.readBigUInt64BE(offset + 2));
      headerLength = 10;
    }

    // Reject frames exceeding max payload size at the frame level
    if (payloadLength > MAX_PAYLOAD_BYTES) {
      // Drain the bad frame from the buffer and reject
      client.buffer = Buffer.alloc(0);
      return frames;
    }

    const maskLength = masked ? 4 : 0;
    const frameLength = headerLength + maskLength + payloadLength;
    if (offset + frameLength > client.buffer.length) break;

    const maskOffset = offset + headerLength;
    const payloadOffset = maskOffset + maskLength;
    const payload = Buffer.from(client.buffer.subarray(payloadOffset, payloadOffset + payloadLength));

    if (masked) {
      const mask = client.buffer.subarray(maskOffset, maskOffset + 4);
      for (let index = 0; index < payload.length; index += 1) {
        payload[index] ^= mask[index % 4];
      }
    }

    frames.push({
      fin: (first & 0x80) !== 0,
      opcode: first & 0x0f,
      payload
    });

    offset += frameLength;
  }

  client.buffer = client.buffer.subarray(offset);
  return frames;
}

function encodeFrame(payload, opcode = 0x01) {
  const length = payload.length;
  if (length < 126) {
    return Buffer.concat([Buffer.from([0x80 | opcode, length]), payload]);
  }
  if (length < 65536) {
    const header = Buffer.alloc(4);
    header[0] = 0x80 | opcode;
    header[1] = 126;
    header.writeUInt16BE(length, 2);
    return Buffer.concat([header, payload]);
  }

  const header = Buffer.alloc(10);
  header[0] = 0x80 | opcode;
  header[1] = 127;
  header.writeBigUInt64BE(BigInt(length), 2);
  return Buffer.concat([header, payload]);
}
